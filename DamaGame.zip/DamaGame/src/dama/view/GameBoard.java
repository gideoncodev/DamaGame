package dama.view;

import dama.controller.FileMenuListener.*;
import dama.model.board.BoardUtils;
import dama.model.board.Board;

import java.io.File;
import java.io.IOException;
import java.util.*;
import java.util.List;
import java.awt.*;
import java.awt.image.BufferedImage;
import javax.swing.*;
import javax.imageio.ImageIO;

public class GameBoard {

	private final JFrame gameFrame;
	private final BoardPanel boardPanel;
	private final Board damaBoard;

	private final static Dimension OUTER_FRAME_DIMENSION = new Dimension(600,600);
	private final static Dimension BOARD_PANEL_DIMENSION = new Dimension(400, 350);
	private final static Dimension TILE_PANEL_DIMENSION = new Dimension(10, 10);
	private final static String defaultPieceImagePath = "src/dama/view/images/";

	private final Color lightTileColor = Color.decode("#F4F6F4");
    private final Color darkTileColor = Color.decode("#0C6B09");

	public GameBoard() {

		final JMenuBar damaMenuBar = this.populateMenuBar();

		this.gameFrame = new JFrame("Dama");
		this.gameFrame.setLayout(new BorderLayout());
		this.gameFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		this.gameFrame.setJMenuBar(damaMenuBar);

		this.damaBoard = Board.createStandardBoard();
		this.boardPanel = new BoardPanel();
		this.gameFrame.add(this.boardPanel, BorderLayout.CENTER);

		this.gameFrame.pack();
		this.gameFrame.setSize(OUTER_FRAME_DIMENSION);
		this.gameFrame.setVisible(true);
	}

	public JFrame getGameFrame() {
		return this.gameFrame;
	}

	private JMenuBar populateMenuBar() {
		final JMenuBar damaMenuBar = new JMenuBar();
		damaMenuBar.add(this.createFileMenu());
		return damaMenuBar;
	}

	private JMenu createFileMenu() {
		final JMenu fileMenu = new JMenu("File");
		final JMenuItem openFile = new JMenuItem("Open");
		final JMenuItem exitMenu = new ExitMenuItem("Exit");

		openFile.addActionListener(new OpenListener());
		exitMenu.addActionListener(new ExitListener());

		fileMenu.add(openFile);
		fileMenu.addSeparator();
		fileMenu.add(exitMenu);

		return fileMenu;
	}

	public class ExitMenuItem extends JMenuItem {
		ExitMenuItem(final String name) {
			super(name);
		}

		public JFrame getParentFrame() {
			return GameBoard.this.getGameFrame();
		}

	}

	private class BoardPanel extends JPanel {

		final List<TilePanel> boardTiles;

		BoardPanel(){
			super(new GridLayout(8,8));
			this.boardTiles = new ArrayList<>();

			for(int i = 0; i < BoardUtils.NUM_TILES; i++) {
				final TilePanel tilePanel = new TilePanel(this, i);
				this.boardTiles.add(tilePanel);
				this.add(tilePanel);
			}
			this.setPreferredSize(BOARD_PANEL_DIMENSION);
			this.validate();
		}
	}

	private class TilePanel extends JPanel {
		private final int tileId;

		TilePanel(final BoardPanel boardPanel,
				  final int tileId) {
			super(new GridBagLayout());
			this.tileId = tileId;
			this.setPreferredSize(TILE_PANEL_DIMENSION);
			this.assignTileColor();
			this.assignTilePieceIcon(damaBoard);
			this.validate();
		}

		public void assignTilePieceIcon(final Board board) {
			this.removeAll();
			if(board.getTile(this.tileId).isTileOccupied()) {
				try {
					BufferedImage image = ImageIO.read(new File(defaultPieceImagePath +
                            board.getTile(this.tileId).getPiece().getPieceAlliance().toString().substring(0, 1) + "" +
                            board.getTile(this.tileId).getPiece().toString() +
                            ".png"));
					final Image imageIcon = image.getScaledInstance(50, 50, Image.SCALE_SMOOTH);
					this.add(new JLabel(new ImageIcon(imageIcon)));
				} catch(IOException e) {
					e.printStackTrace();
				}
			}
		}

		public void assignTileColor() {
			 if (BoardUtils.FIRST_ROW.get(this.tileId) ||
                BoardUtils.THIRD_ROW.get(this.tileId) ||
                BoardUtils.FIFTH_ROW.get(this.tileId) ||
                BoardUtils.SEVENTH_ROW.get(this.tileId)) {
                this.setBackground(this.tileId % 2 == 0 ? lightTileColor : darkTileColor);
            } else if(BoardUtils.SECOND_ROW.get(this.tileId) ||
                      BoardUtils.FOURTH_ROW.get(this.tileId) ||
                      BoardUtils.SIXTH_ROW.get(this.tileId)  ||
                      BoardUtils.EIGHTH_ROW.get(this.tileId)) {
                this.setBackground(this.tileId % 2 != 0 ? lightTileColor : darkTileColor);
            }
		}
	}
}