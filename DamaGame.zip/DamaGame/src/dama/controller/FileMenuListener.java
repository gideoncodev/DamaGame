package dama.controller;

import java.awt.event.*;

public class FileMenuListener implements ActionListener {
	@Override
	public void actionPerformed(ActionEvent e) {
		System.out.println("Click the Open Menu Item!");
	}
}