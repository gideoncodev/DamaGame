package dama.controller;

import dama.view.GameBoard;
import dama.view.GameBoard.*;

import java.awt.event.*;
import javax.swing.*;

public class FileMenuListener {

	private final static GameBoard GAME_BOARD = new GameBoard();

	public static class OpenListener implements ActionListener {
		@Override
		public void actionPerformed(ActionEvent e) {
			System.out.println("Click the Open Menu Item!");
		}
	}

	public static class ExitListener implements ActionListener {

		@Override
		public void actionPerformed(ActionEvent e) {
			final ExitMenuItem exitMenu = (ExitMenuItem) e.getSource();
			exitMenu.getParentFrame().dispose();
			System.out.println("Click the Exit Menu Item!");
			System.exit(0);
		}
	}
}