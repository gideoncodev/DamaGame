package dama.model;

public enum Alliance {
	WHITE,
	BLACK
}