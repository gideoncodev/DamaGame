package dama.model.board;

public class Board {
	
	public Tile getTile(final int tileCoordinate) {
		return null;
	}
}