package dama.model.board;

public class Move {
	
}