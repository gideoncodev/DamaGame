package dama.model.board;

public class Board {
	
}